module IronCore
  class IronTokenProvider
    def initialize(token)
      @token = token
    end

    def token
      @token
    end
  end
end