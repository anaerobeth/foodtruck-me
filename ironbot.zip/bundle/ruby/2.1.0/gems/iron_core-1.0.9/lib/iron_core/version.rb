module IronCore
  VERSION = "1.0.9"

  def self.version
    VERSION
  end
end
