module IronCore
  class Error < StandardError
  end

  class HttpError < Rest::HttpError

  end
end
