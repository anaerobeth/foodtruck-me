require 'test/unit'
require 'yaml'
require_relative 'test_base'

class TestTemp < TestBase
  def setup
    super

  end


  def test_post_file
    
  end

end

