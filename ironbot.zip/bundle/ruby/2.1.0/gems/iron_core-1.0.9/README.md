Common library among www.iron.io Ruby clients.
