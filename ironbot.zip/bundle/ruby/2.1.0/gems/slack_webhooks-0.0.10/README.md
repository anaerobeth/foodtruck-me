This gem helps dealing with Slack Webhooks, both outgoing and incoming. Incoming it will parse the 
posted body and allow you to access the values as well as make it easy to send a response back to the 
right Slack channel. 

