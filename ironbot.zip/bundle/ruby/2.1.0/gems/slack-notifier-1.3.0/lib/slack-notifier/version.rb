module Slack
  class Notifier
    VERSION = "1.3.0"
  end
end
