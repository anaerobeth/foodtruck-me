module Rest
  VERSION = "3.0.6"
end
